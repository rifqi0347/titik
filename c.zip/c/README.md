# InstagramStoryNextpost
 Instagram Story Viewer by Nextpost [nulled]
Ini script nulled ya bajingan, di upload sama orang di Grup, gatau w ada log atau enggak, w cuma edit di inputan License Key, kalo takut gausah dipake kontol.

Paling males w dikatain logger, bajingan kontol jembottt!
